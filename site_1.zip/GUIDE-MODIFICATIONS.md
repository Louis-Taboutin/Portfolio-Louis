# Guide : modifier le site toi-même

Ce guide t'explique comment ajouter une photo, un point (bullet), ou une carte complète
(comme "VivaTech" ou "Paris Builds") sans avoir besoin de redemander à Claude. Trois choses
à savoir avant de commencer :

- Chaque page (`index.html`, `finance.html`, `ia.html`, `solidarite.html`, `photo.html`)
  est un fichier texte que tu peux ouvrir avec **n'importe quel éditeur de texte**
  (Bloc-notes, TextEdit, ou mieux : [VS Code](https://code.visualstudio.com/), gratuit).
- Le style visuel (couleurs, tailles, espacements) est **entièrement dans `style.css`** —
  tu n'as jamais besoin d'y toucher pour ajouter du contenu, seulement le HTML.
- Après une modification, ouvre juste le fichier `.html` dans ton navigateur pour voir le résultat
  (double-clic dessus). Pas besoin de redéployer pour tester en local.

---

## 1. Ajouter une photo

Depuis l'optimisation, les images ne sont plus du texte encodé dans la page : ce sont de vrais
fichiers dans le dossier `assets/img/`. Ça rend l'ajout très simple.

**Étape 1** — Dépose ta photo dans `assets/img/`. Renomme-la avec un nom simple, sans espaces ni
accents, par exemple `visite-google-2026.jpg`.

**Étape 2** — Dans le fichier `.html` de la page concernée, ajoute une balise `<img>` à
l'endroit voulu :

```html
<img src="assets/img/visite-google-2026.jpg" alt="Description de la photo pour les lecteurs d'écran" />
```

Le `src` doit correspondre exactement au nom de fichier que tu as mis dans `assets/img/`.
Le `alt` n'est pas affiché à l'écran, mais décris toujours ce que montre la photo (accessibilité + référencement Google).

**Astuce taille** — pour ne pas alourdir le site, essaie de rester sous les 300-400 Ko par photo
(1000px de large suffit largement pour le web). Si ta photo est plus lourde, tu peux la compresser
gratuitement sur [squoosh.app](https://squoosh.app) avant de l'ajouter.

---

## 2. Ajouter une carte complète (comme "VivaTech")

Une "carte" (project-card) regroupe une photo (ou plusieurs), un titre, un texte, et des petites
étiquettes ("stack-pill"). Voici le modèle exact utilisé pour VivaTech, à copier-coller et adapter.

**Où le trouver / où le mettre** : dans `ia.html` (ou `finance.html`, `solidarite.html`), cherche
`<div class="projects-grid">` — toutes les cartes de la page sont dedans, les unes après les
autres. Colle ta nouvelle carte juste avant la balise `</div>` qui ferme `projects-grid`
(c'est-à-dire à la toute fin, après la dernière carte existante).

```html
<article class="project-card">
  <span class="project-tag">Type d'événement</span>
  <h3 class="project-title">Titre de ta section</h3>

  <div class="project-gallery">
    <img src="assets/img/ma-photo-1.jpg" alt="Description photo 1" />
    <img src="assets/img/ma-photo-2.jpg" alt="Description photo 2" />
  </div>

  <p class="project-desc">
    Ton texte de description ici. Explique le contexte, ce que tu as fait,
    avec qui, et pourquoi c'est intéressant.
  </p>

  <div class="project-stack">
    <span class="stack-pill">Mot-clé 1</span>
    <span class="stack-pill">Mot-clé 2</span>
  </div>
</article>
```

**Ce que tu peux changer sans risque** :
- `project-tag` : la petite étiquette au-dessus du titre (ex: "Hackathon", "Salon tech").
- `project-title` : le titre de ta carte.
- Les `<img>` : ajoute-en autant que tu veux, ou seulement une.
- `project-desc` : ton paragraphe de texte.
- `stack-pill` : ajoute ou retire des étiquettes (mots-clés) librement.

**Piège à éviter** : ne casse jamais le nombre de balises ouvrantes/fermantes. Chaque `<div ...>`
doit avoir son `</div>`, chaque `<article ...>` son `</article>`. Si le site s'affiche bizarrement
après ta modif, c'est souvent qu'une balise fermante manque quelque part.

### Photos qui gardent leur format d'origine (pas de recadrage)

Par défaut, `project-gallery` recadre les photos en petits carrés uniformes. Si tu préfères que
tes photos gardent leurs proportions d'origine (utile pour des photos portrait très hautes,
comme "Aktionnaire Day"), ajoute simplement `natural` à la classe :

```html
<div class="project-gallery natural">
  <img src="assets/img/ma-photo.jpg" alt="Description" />
</div>
```

---

## 3. Ajouter des points (bullet points)

Utilisés dans les sections Expériences et Formation. Modèle :

```html
<ul class="timeline-list">
  <li>Premier point</li>
  <li>Deuxième point</li>
  <li>Troisième point</li>
</ul>
```

Ajoute ou retire des `<li>...</li>` librement, un par ligne/point.

---

## 4. Un mot sur les traductions (FR/EN)

Si tu remarques des attributs `data-i18n="quelque-chose"` dans le code existant, c'est ce qui
permet la bascule français/anglais (bouton en haut de page). **Tu n'es pas obligé de t'en
occuper** : si tu ajoutes du texte SANS cet attribut, il restera simplement affiché tel quel
dans les deux langues (pas grave si c'est en français en mode anglais, c'est juste moins poli).

Si tu veux vraiment le traduire, il faut :
1. Ajouter `data-i18n="ma-cle-unique"` sur la balise concernée.
2. Ouvrir `i18n.js`, et ajouter une ligne dans `window.I18N` :
   ```js
   "ma-cle-unique": {"fr": "Ton texte en français", "en": "Your text in English"},
   ```
   (colle-la n'importe où dans la longue liste, juste avant une virgule existante)

C'est optionnel — si ça te semble compliqué, ignore cette section sans problème.

---

## 5. Récapitulatif express

| Je veux... | Je touche... |
|---|---|
| Ajouter une photo | Déposer le fichier dans `assets/img/` + une balise `<img>` |
| Ajouter une carte (section) | Copier le modèle de la partie 2, coller avant `</div>` de `projects-grid` |
| Ajouter des points | Ajouter des `<li>...</li>` dans un `<ul class="timeline-list">` |
| Changer une couleur / une taille | `style.css` uniquement |
| Traduire un nouveau texte | `data-i18n` + `i18n.js` (optionnel) |

En cas de doute ou si quelque chose casse, tu peux toujours me redonner le fichier modifié et je
vérifie / corrige.
