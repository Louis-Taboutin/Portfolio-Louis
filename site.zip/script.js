(function() {
      var LANG_KEY = 'louis-site-lang';
      function getLang() {
        var saved = null; try { saved = localStorage.getItem(LANG_KEY); } catch (e) {}
        if (saved === 'fr' || saved === 'en') return saved;
        var nav = (navigator.language || navigator.userLanguage || 'fr').toLowerCase();
        return nav.indexOf('fr') === 0 ? 'fr' : 'en';
      }
      function setLang(lang) {
        document.documentElement.setAttribute('lang', lang);
        document.querySelectorAll('[data-i18n]').forEach(function(el) {
          var key = el.getAttribute('data-i18n');
          if (window.I18N && window.I18N[key] && window.I18N[key][lang] !== undefined) {
            el.textContent = window.I18N[key][lang];
          }
        });
        document.querySelectorAll('[data-i18n-html]').forEach(function(el) {
          var key = el.getAttribute('data-i18n-html');
          if (window.I18N_HTML && window.I18N_HTML[key] && window.I18N_HTML[key][lang] !== undefined) {
            el.innerHTML = window.I18N_HTML[key][lang];
          }
        });
        document.querySelectorAll('.lang-toggle-label').forEach(function(el) {
          el.textContent = lang === 'fr' ? 'EN' : 'FR';
        });
        if (window.PAGE_TITLE_I18N && window.PAGE_TITLE_I18N[lang]) {
          document.title = window.PAGE_TITLE_I18N[lang];
        }
        try { localStorage.setItem(LANG_KEY, lang); } catch (e) {}
      }
      window.toggleSiteLang = function() {
        var current = document.documentElement.getAttribute('lang') === 'en' ? 'en' : 'fr';
        setLang(current === 'fr' ? 'en' : 'fr');
      };
      document.addEventListener('DOMContentLoaded', function() {
        setLang(getLang());
      });
    })();

(function() {
      var THEME_KEY = 'louis-site-theme';
      function getTheme() {
        var saved = null; try { saved = localStorage.getItem(THEME_KEY); } catch (e) {}
        if (saved === 'light' || saved === 'dark') return saved;
        return window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
      }
      function setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        document.querySelectorAll('.theme-toggle-icon').forEach(function(el) {
          el.textContent = theme === 'light' ? 'Dark' : 'Light';
        });
        try { localStorage.setItem(THEME_KEY, theme); } catch (e) {}
      }
      window.toggleSiteTheme = function() {
        var current = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
        setTheme(current === 'light' ? 'dark' : 'light');
      };
      document.addEventListener('DOMContentLoaded', function() {
        setTheme(getTheme());
      });
    })();

window.openQuickSummary = function() {
      document.getElementById('quicksum-overlay').classList.add('is-open');
      document.body.style.overflow = 'hidden';
    };
    window.closeQuickSummary = function() {
      document.getElementById('quicksum-overlay').classList.remove('is-open');
      document.body.style.overflow = '';
    };
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') window.closeQuickSummary();
    });
    document.addEventListener('click', function(e) {
      if (e.target && e.target.id === 'quicksum-overlay') window.closeQuickSummary();
    });

window.openContactForm = function() {
      document.getElementById('contact-overlay').classList.add('is-open');
      document.body.style.overflow = 'hidden';
    };
    window.closeContactForm = function() {
      document.getElementById('contact-overlay').classList.remove('is-open');
      document.body.style.overflow = '';
    };
    window.submitContactForm = function(e) {
      e.preventDefault();
      var name = document.getElementById('contact-name').value;
      var email = document.getElementById('contact-email').value;
      var message = document.getElementById('contact-message').value;
      var subject = encodeURIComponent('Contact depuis le portfolio - ' + name);
      var body = encodeURIComponent(message + '\n\n---\n' + name + ' (' + email + ')');
      window.location.href = 'mailto:louis.taboutin@dauphine.eu?subject=' + subject + '&body=' + body;
      return false;
    };
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') { window.closeContactForm(); }
    });
    document.addEventListener('click', function(e) {
      if (e.target && e.target.id === 'contact-overlay') window.closeContactForm();
    });

(function() {
      // ============ CONSOLE MESSAGE ============
      console.log('%cTu regardes le code, on devrait discuter ;) -> louis.taboutin@dauphine.eu', 'color:#5b8def; font-family:monospace; font-size:14px; padding:6px 0;');
      console.log('%cAstuce : tape ` (backtick) sur le site pour ouvrir un petit terminal cache.', 'color:#a1a1aa; font-family:monospace; font-size:12px;');

      // ============ TERMINAL EASTER EGG ============
      var termOverlay = document.getElementById('terminal-overlay');
      var termBody = document.getElementById('terminal-body');
      var termInput = document.getElementById('terminal-input');

      function termPrint(html) {
        var line = document.createElement('div');
        line.className = 'terminal-line';
        line.innerHTML = html;
        termBody.appendChild(line);
        termBody.scrollTop = termBody.scrollHeight;
      }

      var COMMANDS = {
        help: 'Commandes : <span class="terminal-prompt-color">whoami</span>, <span class="terminal-prompt-color">skills</span>, <span class="terminal-prompt-color">experience</span>, <span class="terminal-prompt-color">education</span>, <span class="terminal-prompt-color">contact</span>, <span class="terminal-prompt-color">clear</span>, <span class="terminal-prompt-color">exit</span>',
        whoami: "Louis TABOUTIN - Etudiant MSc Finance @ Universite Paris Dauphine - PSL. Co-fondateur de DAU'IA. President d'EPICOOP PSL.",
        skills: "Python, Excel/VBA, Bloomberg, SQL, modelisation financiere, valorisation par multiples, backtesting quantitatif (Fama-French, Piotroski).",
        experience: "Origination M&amp;A (Matrila), Gestion de patrimoine (AAG Finance), RH &amp; communication (RE/MAX), Assistant des ventes (Lyhin Engineering, Malaisie).",
        education: "MSc Finance (Universite Paris Dauphine - PSL, 2025-2028), Y Combinator Startup School, Licences Management et Mathematiques &amp; Informatique.",
        contact: 'louis.taboutin@dauphine.eu - <a href="https://fr.linkedin.com/in/louis-taboutin" target="_blank" style="color:#5b8def;">LinkedIn</a>',
      };

      function runCommand(raw) {
        var cmd = raw.trim().toLowerCase();
        termPrint('<span class="terminal-prompt-color">&gt;</span> ' + raw);
        if (cmd === '') return;
        if (cmd === 'clear') { termBody.innerHTML = ''; return; }
        if (cmd === 'exit') { closeTerminal(); return; }
        if (COMMANDS[cmd]) { termPrint(COMMANDS[cmd]); return; }
        termPrint('Commande inconnue : ' + cmd + '. Tape <span class="terminal-prompt-color">help</span>.');
      }

      window.openTerminal = function() {
        termOverlay.classList.add('is-open');
        document.body.style.overflow = 'hidden';
        setTimeout(function() { termInput.focus(); }, 50);
      };
      function closeTerminal() {
        termOverlay.classList.remove('is-open');
        document.body.style.overflow = '';
      }
      window.closeTerminal = closeTerminal;

      if (termInput) {
        termInput.addEventListener('keydown', function(e) {
          if (e.key === 'Enter') {
            runCommand(termInput.value);
            termInput.value = '';
          }
        });
      }
      if (termOverlay) {
        termOverlay.addEventListener('click', function(e) {
          if (e.target === termOverlay) closeTerminal();
        });
      }

      // ============ KEYBOARD SHORTCUTS (g + lettre) ============
      var gPressed = false;
      var gTimeout = null;
      var ROUTES = {
        h: 'index.html#top',
        e: 'index.html#experiences',
        o: 'index.html#formation',
        f: 'finance.html',
        a: 'ia.html',
        s: 'solidarite.html',
        p: 'photo.html',
      };

      document.addEventListener('keydown', function(e) {
        var tag = (e.target.tagName || '').toLowerCase();
        var typing = tag === 'input' || tag === 'textarea' || e.target.isContentEditable;

        if (e.key === 'Escape') {
          closeTerminal();
          if (window.closeQuickSummary) window.closeQuickSummary();
          if (window.closeContactForm) window.closeContactForm();
          return;
        }

        if (typing) return;

        if (e.key === '`') {
          e.preventDefault();
          window.openTerminal();
          return;
        }

        if (e.key.toLowerCase() === 'g' && !e.metaKey && !e.ctrlKey) {
          gPressed = true;
          clearTimeout(gTimeout);
          gTimeout = setTimeout(function() { gPressed = false; }, 1200);
          return;
        }

        if (gPressed && ROUTES[e.key.toLowerCase()]) {
          gPressed = false;
          window.location.href = ROUTES[e.key.toLowerCase()];
        }
      });
    })();
  // ============ INTRO LOADER ============
  (function() {
    var loader = document.getElementById('intro-loader');
    if (!loader) return;
    var canvas = document.getElementById('intro-canvas');
    var ctx = canvas.getContext('2d');
    var dpr = window.devicePixelRatio || 1;
    var w, h, nodes = [], t = 0;

    function resize() {
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();

    // Generate neural net nodes for intro
    for (var i = 0; i < 60; i++) {
      nodes.push({
        x: Math.random() * w, y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.6, vy: (Math.random() - 0.5) * 0.6,
        r: 1.2 + Math.random() * 1.5, ph: Math.random() * 6.28
      });
    }

    function introColor() {
      var lt = document.documentElement.getAttribute('data-theme') === 'light';
      return lt ? '30,70,180' : '91,141,239';
    }

    function drawIntro() {
      ctx.clearRect(0, 0, w, h);
      t++;
      var cd = Math.min(w, h) * 0.15;
      var rgb = introColor();
      // Move
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i]; n.x += n.vx; n.y += n.vy;
        if (n.x < -20) n.x = w + 20; if (n.x > w + 20) n.x = -20;
        if (n.y < -20) n.y = h + 20; if (n.y > h + 20) n.y = -20;
      }
      // Connections
      for (var i = 0; i < nodes.length; i++) {
        for (var j = i + 1; j < nodes.length; j++) {
          var dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y;
          var d = Math.sqrt(dx * dx + dy * dy);
          if (d < cd) {
            var a = (1 - d / cd) * 0.18;
            ctx.beginPath(); ctx.moveTo(nodes[i].x, nodes[i].y); ctx.lineTo(nodes[j].x, nodes[j].y);
            ctx.strokeStyle = 'rgba(' + rgb + ',' + a.toFixed(3) + ')'; ctx.lineWidth = 0.5; ctx.stroke();
          }
        }
      }
      // Nodes
      for (var i = 0; i < nodes.length; i++) {
        var n = nodes[i], p = (Math.sin(t * 0.04 + n.ph) + 1) / 2;
        ctx.beginPath(); ctx.arc(n.x, n.y, n.r + p * 0.8, 0, 6.28);
        ctx.fillStyle = 'rgba(' + rgb + ',' + (0.2 + p * 0.5).toFixed(3) + ')';
        ctx.fill();
      }
      if (!loader.classList.contains('intro-done')) requestAnimationFrame(drawIntro);
    }
    requestAnimationFrame(drawIntro);

    // Fade out after load
    window.addEventListener('load', function() {
      setTimeout(function() {
        loader.classList.add('intro-done');
        setTimeout(function() { loader.remove(); }, 700);
      }, 800);
    });
  })();

  // ============ ANIMATED BACKGROUNDS (canvas) ============
  (function() {
    var glowBgs = document.querySelectorAll('.glow-bg');
    if (!glowBgs.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    function rand(a, b) { return a + Math.random() * (b - a); }

    function isLight() {
      return document.documentElement.getAttribute('data-theme') === 'light';
    }

    // Color palettes for dark and light modes
    function getColors() {
      if (isLight()) {
        return {
          netR: 30, netG: 70, netB: 180,
          coolStars: ['rgba(30,70,180,', 'rgba(50,90,200,', 'rgba(25,60,160,'],
          warmStars: ['rgba(160,110,50,', 'rgba(140,90,30,', 'rgba(170,120,60,'],
          warmNetR: 140, warmNetG: 100, warmNetB: 40
        };
      }
      return {
        netR: 91, netG: 141, netB: 239,
        coolStars: ['rgba(91,141,239,', 'rgba(110,155,230,', 'rgba(75,120,210,'],
        warmStars: ['rgba(200,165,110,', 'rgba(180,140,90,', 'rgba(210,175,130,'],
        warmNetR: 160, warmNetG: 140, warmNetB: 100
      };
    }

    function getPageType(bg) {
      if (bg.closest('.glow-warm')) return 'warm';
      var p = window.location.pathname;
      if (p.indexOf('finance') !== -1) return 'finance';
      if (p.indexOf('ia') !== -1) return 'ia';
      if (p.indexOf('solidarite') !== -1) return 'warm';
      return 'default';
    }

    glowBgs.forEach(function(bg) {
      var type = getPageType(bg);
      var canvas = document.createElement('canvas');
      bg.appendChild(canvas);
      var ctx = canvas.getContext('2d');
      var dpr = window.devicePixelRatio || 1;
      var w, h, stars = [], netNodes = [];

      function resize() {
        var r = bg.getBoundingClientRect();
        w = r.width; h = r.height;
        canvas.width = w * dpr; canvas.height = h * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        generateNet();
      }

      // Neural network nodes (subtle, everywhere)
      function generateNet() {
        netNodes = [];
        var density = (type === 'warm') ? 12 : 25;
        for (var i = 0; i < density; i++) {
          netNodes.push({
            x: rand(0, w), y: rand(0, h),
            vx: rand(-0.08, 0.08), vy: rand(-0.08, 0.08),
            r: rand(0.8, 1.8), ph: rand(0, 6.28)
          });
        }
      }

      resize();
      var rt; window.addEventListener('resize', function() { clearTimeout(rt); rt = setTimeout(resize, 250); });

      // Shooting star spawner
      function spawnStar(warm) {
        var angle, speed, length, color, x, y;
        var col = getColors();
        if (warm) {
          angle = rand(-130, -50) * Math.PI / 180;
          speed = rand(0.2, 0.55); length = rand(12, 30);
          color = col.warmStars[Math.floor(Math.random() * col.warmStars.length)];
          x = rand(0, w); y = h + rand(5, 20);
        } else {
          angle = rand(18, 52) * Math.PI / 180;
          speed = rand(1.5, 4.5); length = rand(50, 180);
          color = col.coolStars[Math.floor(Math.random() * col.coolStars.length)];
          if (Math.random() < 0.5) { x = rand(-25, -5); y = rand(0, h * 0.7); }
          else { x = rand(0, w * 0.8); y = rand(-25, -5); }
        }
        stars.push({ x: x, y: y, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed,
          length: length, color: color, life: 0, maxLife: rand(80, 240), warm: warm });
      }

      // Draw neural net layer
      function drawNet(t) {
        var connectDist = Math.min(w, h) * 0.14;
        var isWarm = (type === 'warm');
        var col = getColors();
        var baseR = isWarm ? col.warmNetR : col.netR;
        var baseG = isWarm ? col.warmNetG : col.netG;
        var baseB = isWarm ? col.warmNetB : col.netB;

        for (var i = 0; i < netNodes.length; i++) {
          var n = netNodes[i];
          n.x += n.vx; n.y += n.vy;
          if (n.x < -30) n.x = w + 30; if (n.x > w + 30) n.x = -30;
          if (n.y < -30) n.y = h + 30; if (n.y > h + 30) n.y = -30;
        }
        // Connections
        for (var i = 0; i < netNodes.length; i++) {
          for (var j = i + 1; j < netNodes.length; j++) {
            var dx = netNodes[i].x - netNodes[j].x, dy = netNodes[i].y - netNodes[j].y;
            var d = Math.sqrt(dx * dx + dy * dy);
            if (d < connectDist) {
              var a = (1 - d / connectDist) * 0.08;
              var pulse = (Math.sin(t * 0.001 + netNodes[i].ph) + 1) / 4;
              a *= 0.6 + pulse;
              ctx.beginPath(); ctx.moveTo(netNodes[i].x, netNodes[i].y); ctx.lineTo(netNodes[j].x, netNodes[j].y);
              ctx.strokeStyle = 'rgba(' + baseR + ',' + baseG + ',' + baseB + ',' + a.toFixed(3) + ')';
              ctx.lineWidth = 0.4; ctx.stroke();
            }
          }
        }
        // Dots
        for (var i = 0; i < netNodes.length; i++) {
          var n = netNodes[i], p = (Math.sin(t * 0.002 + n.ph) + 1) / 2;
          ctx.beginPath(); ctx.arc(n.x, n.y, n.r + p * 0.5, 0, 6.28);
          ctx.fillStyle = 'rgba(' + baseR + ',' + baseG + ',' + baseB + ',' + (0.1 + p * 0.2).toFixed(3) + ')';
          ctx.fill();
        }
      }

      // Draw shooting stars layer
      function drawStars(t, maxCount, spawnRate, warm) {
        if (stars.length < maxCount && Math.random() < spawnRate) spawnStar(warm);
        for (var i = stars.length - 1; i >= 0; i--) {
          var s = stars[i]; s.x += s.vx; s.y += s.vy; s.life++;
          if (s.life > s.maxLife || s.x > w + 200 || s.x < -200 || s.y > h + 200 || s.y < -200) {
            stars.splice(i, 1); continue;
          }
          var a;
          if (s.life < 20) a = s.life / 20;
          else if (s.life > s.maxLife - 30) a = Math.max(0, (s.maxLife - s.life) / 30);
          else a = 0.35 + Math.sin(s.life * 0.03) * 0.2;

          if (s.warm) {
            var pr = 1.2 + Math.sin(s.life * 0.05) * 0.4;
            ctx.beginPath(); ctx.arc(s.x, s.y, pr, 0, 6.28);
            ctx.fillStyle = s.color + (a * 0.5).toFixed(3) + ')';
            ctx.shadowColor = s.color + '0.25)'; ctx.shadowBlur = 6; ctx.fill(); ctx.shadowBlur = 0;
          } else {
            var sp = Math.sqrt(s.vx * s.vx + s.vy * s.vy);
            var ux = s.vx / sp, uy = s.vy / sp;
            var tx = s.x - ux * s.length, ty = s.y - uy * s.length;
            var gr = ctx.createLinearGradient(tx, ty, s.x, s.y);
            gr.addColorStop(0, s.color + '0)');
            gr.addColorStop(0.65, s.color + (a * 0.15).toFixed(3) + ')');
            gr.addColorStop(1, s.color + (a * 0.5).toFixed(3) + ')');
            ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(s.x, s.y);
            ctx.strokeStyle = gr; ctx.lineWidth = 1.2; ctx.lineCap = 'round'; ctx.stroke();
            ctx.beginPath(); ctx.arc(s.x, s.y, 1, 0, 6.28);
            ctx.fillStyle = s.color + a.toFixed(3) + ')';
            ctx.shadowColor = s.color + '0.3)'; ctx.shadowBlur = 4; ctx.fill(); ctx.shadowBlur = 0;
          }
        }
      }

      // Seed
      var isWarm = (type === 'warm');
      for (var s = 0; s < 4; s++) { spawnStar(isWarm); stars[stars.length - 1].life = 20 + rand(0, 60); }

      function loop(t) {
        ctx.clearRect(0, 0, w, h);
        drawNet(t);
        var maxStars = isWarm ? 16 : 12;
        var rate = isWarm ? 0.015 : 0.01;
        drawStars(t, maxStars, rate, isWarm);
        requestAnimationFrame(loop);
      }
      requestAnimationFrame(loop);
    });
  })();

  // ============ REVEAL AU SCROLL (galerie photo) ============
  (function() {
    var items = document.querySelectorAll('.photo-item');
    if (!items.length) return;
    if (!('IntersectionObserver' in window)) {
      items.forEach(function(el) { el.classList.add('is-visible'); });
      return;
    }
    var observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    items.forEach(function(el) { observer.observe(el); });
  })();

  // ============ MOBILE HAMBURGER MENU ============
  (function() {
    var burger = document.getElementById('navbar-burger');
    var nav = document.getElementById('navbar-nav');
    if (!burger || !nav) return;

    burger.addEventListener('click', function() {
      var isOpen = nav.classList.toggle('is-open');
      burger.classList.toggle('is-active');
      burger.setAttribute('aria-expanded', isOpen);
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close on link click
    nav.querySelectorAll('.navbar-link').forEach(function(link) {
      link.addEventListener('click', function() {
        nav.classList.remove('is-open');
        burger.classList.remove('is-active');
        burger.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });

    // Close on escape
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && nav.classList.contains('is-open')) {
        nav.classList.remove('is-open');
        burger.classList.remove('is-active');
        burger.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      }
    });
  })();

  // ============ TIMELINE FILTERS ============
  (function() {
    var filters = document.getElementById('timeline-filters');
    if (!filters) return;
    var buttons = filters.querySelectorAll('.tl-filter');
    var items = document.querySelectorAll('.timeline-item[data-category]');
    var labels = document.querySelectorAll('.subsection-label');

    buttons.forEach(function(btn) {
      btn.addEventListener('click', function() {
        buttons.forEach(function(b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        var filter = btn.getAttribute('data-filter');

        items.forEach(function(item) {
          if (filter === 'all' || item.getAttribute('data-category') === filter) {
            item.classList.remove('is-hidden');
          } else {
            item.classList.add('is-hidden');
          }
        });

        // Show/hide subsection labels based on visible items
        labels.forEach(function(label) {
          var timeline = label.nextElementSibling;
          if (!timeline || !timeline.classList.contains('timeline')) return;
          var visibleItems = timeline.querySelectorAll('.timeline-item:not(.is-hidden)');
          if (visibleItems.length === 0) {
            label.classList.add('is-hidden');
          } else {
            label.classList.remove('is-hidden');
          }
        });
      });
    });
  })();
